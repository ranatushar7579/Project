"""
Machine Learning Engine for Cardiovascular Disease Prediction
Trains Logistic Regression, Decision Tree, and Random Forest models.
Provides evaluation metrics, confusion matrices, feature importances, and inference.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)

DATA_PATH = os.path.join(os.path.dirname(__file__), 'cardio.csv')

FEATURE_COLS = [
    'age_years', 'gender', 'height', 'weight', 'ap_hi', 'ap_lo',
    'cholesterol', 'gluc', 'smoke', 'alco', 'active', 'Bmi'
]

class CardioMLEngine:
    def __init__(self, data_path=DATA_PATH):
        self.data_path = data_path
        self.df = None
        self.models = {}
        self.scaler = StandardScaler()
        self.metrics = {}
        self.feature_names = [
            'Age (Years)', 'Gender', 'Height (cm)', 'Weight (kg)',
            'Systolic BP (ap_hi)', 'Diastolic BP (ap_lo)',
            'Cholesterol Level', 'Glucose Level',
            'Smoking', 'Alcohol Intake', 'Physical Activity', 'BMI'
        ]
        self.feature_keys = FEATURE_COLS
        self.feature_importances = []

    def load_data(self):
        """Loads and prepares the cardio dataset."""
        if not os.path.exists(self.data_path):
            raise FileNotFoundError(f"Data file not found at {self.data_path}")
        
        self.df = pd.read_csv(self.data_path)
        
        # Ensure calculated fields exist and are clean
        if 'age_years' not in self.df.columns:
            self.df['age_years'] = (self.df['age'] / 365.25).round().astype(int)
        
        if 'Bmi' not in self.df.columns:
            self.df['Bmi'] = (self.df['weight'] / ((self.df['height'] / 100) ** 2)).round(2)
        
        # Clean extreme outliers if any
        self.df = self.df[(self.df['ap_hi'] >= 60) & (self.df['ap_hi'] <= 240)]
        self.df = self.df[(self.df['ap_lo'] >= 40) & (self.df['ap_lo'] <= 190)]
        self.df = self.df[(self.df['height'] >= 100) & (self.df['height'] <= 220)]
        self.df = self.df[(self.df['weight'] >= 30) & (self.df['weight'] <= 200)]
        self.df['Bmi'] = (self.df['weight'] / ((self.df['height'] / 100) ** 2)).round(2)
        
        return self.df

    def train_models(self):
        """Trains Logistic Regression, Decision Tree, and Random Forest."""
        if self.df is None:
            self.load_data()

        X = self.df[self.feature_keys]
        y = self.df['cardio']

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=42, stratify=y
        )

        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # 1. Logistic Regression
        lr = LogisticRegression(max_iter=1000, random_state=42)
        lr.fit(X_train_scaled, y_train)
        self.models['logistic_regression'] = lr

        # 2. Decision Tree
        dt = DecisionTreeClassifier(max_depth=10, min_samples_leaf=30, random_state=42)
        dt.fit(X_train, y_train)
        self.models['decision_tree'] = dt

        # 3. Random Forest (Ensemble)
        rf = RandomForestClassifier(
            n_estimators=100, max_depth=14, min_samples_leaf=20,
            n_jobs=-1, random_state=42
        )
        rf.fit(X_train, y_train)
        self.models['random_forest'] = rf

        # Evaluate Models
        self.metrics = {}
        for name, model in self.models.items():
            if name == 'logistic_regression':
                y_pred = model.predict(X_test_scaled)
                y_prob = model.predict_proba(X_test_scaled)[:, 1]
            else:
                y_pred = model.predict(X_test)
                y_prob = model.predict_proba(X_test)[:, 1]

            cm = confusion_matrix(y_test, y_pred)
            tn, fp, fn, tp = cm.ravel()

            self.metrics[name] = {
                'name': name.replace('_', ' ').title(),
                'accuracy': round(float(accuracy_score(y_test, y_pred) * 100), 2),
                'precision': round(float(precision_score(y_test, y_pred) * 100), 2),
                'recall': round(float(recall_score(y_test, y_pred) * 100), 2),
                'f1_score': round(float(f1_score(y_test, y_pred) * 100), 2),
                'roc_auc': round(float(roc_auc_score(y_test, y_prob) * 100), 2),
                'confusion_matrix': {
                    'tn': int(tn), 'fp': int(fp),
                    'fn': int(fn), 'tp': int(tp)
                },
                'total_test_samples': int(len(y_test))
            }

        # Calculate Feature Importances from Random Forest
        rf_importances = self.models['random_forest'].feature_importances_
        feature_importance_list = []
        for feat, name, imp in zip(self.feature_keys, self.feature_names, rf_importances):
            feature_importance_list.append({
                'feature_key': feat,
                'feature_name': name,
                'importance': round(float(imp * 100), 2)
            })
        feature_importance_list.sort(key=lambda x: x['importance'], reverse=True)
        self.feature_importances = feature_importance_list

        return self.metrics

    def predict_risk(self, patient_data, model_name='random_forest'):
        """
        Predicts cardiovascular risk probability for a given patient dict.
        patient_data keys:
        age_years, gender, height, weight, ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active
        """
        if not self.models:
            self.train_models()

        # Compute BMI if not provided
        height_m = float(patient_data['height']) / 100.0
        bmi = round(float(patient_data['weight']) / (height_m ** 2), 2)
        patient_data['Bmi'] = bmi

        row = [float(patient_data[k]) for k in self.feature_keys]
        row_df = pd.DataFrame([row], columns=self.feature_keys)

        model = self.models.get(model_name, self.models['random_forest'])
        if model_name == 'logistic_regression':
            row_scaled = self.scaler.transform(row_df)
            prob = float(model.predict_proba(row_scaled)[0][1])
        else:
            prob = float(model.predict_proba(row_df)[0][1])

        risk_percent = round(prob * 100, 1)
        
        # Risk Tier Classification
        if risk_percent < 25:
            tier = 'Low Risk'
            tier_gu = 'ઓછું જોખમ'
            color = '#10b981' # emerald
        elif risk_percent < 50:
            tier = 'Moderate Risk'
            tier_gu = 'મધ્યમ જોખમ'
            color = '#f59e0b' # amber
        elif risk_percent < 75:
            tier = 'High Risk'
            tier_gu = 'ઉચ્ચ જોખમ'
            color = '#f97316' # orange
        else:
            tier = 'Critical Risk'
            tier_gu = 'અતિ ગંભીર જોખમ'
            color = '#ef4444' # rose/red

        # BP Classification
        ap_hi = float(patient_data['ap_hi'])
        ap_lo = float(patient_data['ap_lo'])
        if ap_hi < 120 and ap_lo < 80:
            bp_cat = 'Normal'
            bp_cat_gu = 'સામાન્ય'
        elif (120 <= ap_hi <= 129) and ap_lo < 80:
            bp_cat = 'Elevated'
            bp_cat_gu = 'વધેલું બ્લડ પ્રેશર'
        elif (130 <= ap_hi <= 139) or (80 <= ap_lo <= 89):
            bp_cat = 'Hypertension Stage 1'
            bp_cat_gu = 'હાઈપરટેન્શન સ્ટેજ ૧'
        else:
            bp_cat = 'Hypertension Stage 2'
            bp_cat_gu = 'હાઈપરટેન્શન સ્ટેજ ૨'

        # BMI Classification
        if bmi < 18.5:
            bmi_cat = 'Underweight'
            bmi_cat_gu = 'ઓછું વજન'
        elif bmi < 25.0:
            bmi_cat = 'Normal'
            bmi_cat_gu = 'સામાન્ય વજન'
        elif bmi < 30.0:
            bmi_cat = 'Overweight'
            bmi_cat_gu = 'વધારે વજન'
        elif bmi < 35.0:
            bmi_cat = 'Obesity Class 1'
            bmi_cat_gu = 'સ્થૂળતા વર્ગ ૧'
        else:
            bmi_cat = 'Severe Obesity'
            bmi_cat_gu = 'ગંભીર સ્થૂળતા'

        # Key Drivers / Factors
        drivers = []
        if ap_hi >= 130 or ap_lo >= 85:
            drivers.append({'factor': f"Elevated Blood Pressure ({int(ap_hi)}/{int(ap_lo)} mmHg)", 'factor_gu': f"હાઈ બ્લડ પ્રેશર ({int(ap_hi)}/{int(ap_lo)} mmHg)", 'impact': 'high', 'type': 'negative'})
        if int(patient_data['cholesterol']) > 1:
            drivers.append({'factor': f"High Cholesterol (Level {int(patient_data['cholesterol'])})", 'factor_gu': f"હાઈ કોલેસ્ટ્રોલ (સ્તર {int(patient_data['cholesterol'])})", 'impact': 'high', 'type': 'negative'})
        if float(patient_data['age_years']) >= 55:
            drivers.append({'factor': f"Age Factor ({int(patient_data['age_years'])} Years)", 'factor_gu': f"ઉંમર પરિબળ ({int(patient_data['age_years'])} વર્ષ)", 'impact': 'medium', 'type': 'negative'})
        if bmi >= 28.0:
            drivers.append({'factor': f"High BMI ({bmi} kg/m²)", 'factor_gu': f"વધારે BMI ({bmi} kg/m²)", 'impact': 'medium', 'type': 'negative'})
        if int(patient_data['smoke']) == 1:
            drivers.append({'factor': 'Active Tobacco Smoking', 'factor_gu': 'ધૂમ્રપાન ટેવ', 'impact': 'high', 'type': 'negative'})
        if int(patient_data['gluc']) > 1:
            drivers.append({'factor': f"Elevated Glucose (Level {int(patient_data['gluc'])})", 'factor_gu': f"વધારે ગ્લુકોઝ (સ્તર {int(patient_data['gluc'])})", 'impact': 'medium', 'type': 'negative'})
        if int(patient_data['active']) == 1:
            drivers.append({'factor': 'Physically Active Lifestyle', 'factor_gu': 'નિયમિત શારીરિક કસરત', 'impact': 'positive', 'type': 'positive'})
        else:
            drivers.append({'factor': 'Sedentary Lifestyle', 'factor_gu': 'બેઠાડુ જીવનશૈલી', 'impact': 'medium', 'type': 'negative'})

        # Clinical Recommendations
        recommendations = []
        recommendations_gu = []
        if ap_hi >= 130 or ap_lo >= 85:
            recommendations.append("Monitor blood pressure daily and consult a cardiologist to discuss antihypertensive therapy.")
            recommendations_gu.append("દરરોજ બ્લડ પ્રેશર તપાસો અને હૃદયરોગ નિષ્ણાત સાથે બ્લડ પ્રેશર નિયંત્રણ માટે સલાહ લો.")
        if int(patient_data['cholesterol']) > 1:
            recommendations.append("Follow a heart-healthy Mediterranean diet low in saturated fats; request a lipid profile panel.")
            recommendations_gu.append("સેચ્યુરેટેડ ફેટ વગરનો પૌષ્ટિક આહાર લો અને લિપિડ પ્રોફાઇલ ટેસ્ટ કરાવો.")
        if bmi >= 25.0:
            recommendations.append("Target a gradual 5-10% weight reduction via portion control and caloric deficit.")
            recommendations_gu.append("નિયમિત કસરત અને યોગ્ય ડાયેટ દ્વારા ૫ થી ૧૦% વજન ઘટાડવાનું લક્ષ્ય રાખો.")
        if int(patient_data['smoke']) == 1:
            recommendations.append("Cessation of smoking significantly cuts CVD risk within 12 months.")
            recommendations_gu.append("ધૂમ્રપાન તરત જ બંધ કરો, જેનાથી હૃદયરોગનું જોખમ ઝડપથી ઘટશે.")
        if int(patient_data['active']) == 0:
            recommendations.append("Incorporate at least 150 minutes of moderate aerobic exercise (brisk walking) per week.")
            recommendations_gu.append("દર અઠવાડિયે ઓછામાં ઓછી ૧૫૦ મિનિટ ઝડપી ચાલવા જેવી કસરત કરો.")

        if not recommendations:
            recommendations.append("Maintain your healthy routine, balanced diet, and schedule routine annual checkups.")
            recommendations_gu.append("તમારી સ્વસ્થ જીવનશૈલી જાળવી રાખો અને વાર્ષિક રૂટિન હેલ્થ ચેકઅપ કરાવો.")

        return {
            'risk_probability': risk_percent,
            'prediction': 1 if prob >= 0.5 else 0,
            'risk_tier': tier,
            'risk_tier_gu': tier_gu,
            'risk_color': color,
            'bmi': bmi,
            'bmi_category': bmi_cat,
            'bmi_category_gu': bmi_cat_gu,
            'bp_category': bp_cat,
            'bp_category_gu': bp_cat_gu,
            'drivers': drivers,
            'recommendations': recommendations,
            'recommendations_gu': recommendations_gu,
            'model_used': model_name.replace('_', ' ').title(),
            'model_accuracy': self.metrics.get(model_name, {}).get('accuracy', 73.5)
        }

engine = CardioMLEngine()

if __name__ == '__main__':
    print("Loading data & training models...")
    engine.load_data()
    metrics = engine.train_models()
    print("Training complete! Evaluation Metrics:")
    for k, v in metrics.items():
        print(f"[{v['name']}] Acc: {v['accuracy']}% | Prec: {v['precision']}% | Recall: {v['recall']}% | F1: {v['f1_score']}% | AUC: {v['roc_auc']}%")
    
    print("\nTop Feature Importances:")
    for f in engine.feature_importances[:5]:
        print(f" - {f['feature_name']}: {f['importance']}%")
