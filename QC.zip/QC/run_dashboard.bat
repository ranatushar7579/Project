@echo off
title CardioPulse AI - Dashboard Server
echo ========================================================
echo   Starting CardioPulse AI - Cardiovascular Dashboard
echo   Dataset: cardio.csv (68,822 Records)
echo ========================================================
echo.
echo Launching server at http://localhost:5000 ...
start http://localhost:5000
python app.py
pause
