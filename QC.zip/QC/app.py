"""
Flask Web Application for Cardiovascular Disease Analytics & AI Prediction Dashboard
Serves interactive frontend, statistics API, ML predictions, and patient explorer.
"""

import os
import io
import csv
from flask import Flask, render_template, request, jsonify, Response, send_file
from flask_cors import CORS
import pandas as pd
import numpy as np
from ml_engine import engine

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

# Load data and train models once on startup
print("[App] Initializing Cardio ML Engine...")
df = engine.load_data()
model_metrics = engine.train_models()
print("[App] Engine ready! Records loaded:", len(df))

def compute_dataset_stats(data_df):
    """Precomputes all high-level statistical summaries and distributions."""
    total_patients = int(len(data_df))
    cardio_pos = int((data_df['cardio'] == 1).sum())
    cardio_neg = total_patients - cardio_pos
    cardio_rate = round((cardio_pos / total_patients) * 100, 2)
    
    avg_age = round(float(data_df['age_years'].mean()), 1)
    avg_bmi = round(float(data_df['Bmi'].mean()), 1)
    avg_sys = round(float(data_df['ap_hi'].mean()), 1)
    avg_dia = round(float(data_df['ap_lo'].mean()), 1)
    
    smokers = int((data_df['smoke'] == 1).sum())
    alcohol = int((data_df['alco'] == 1).sum())
    active = int((data_df['active'] == 1).sum())
    
    # 1. Age Groups Distribution
    bins = [29, 39, 49, 59, 70]
    labels = ['30-39', '40-49', '50-59', '60-65']
    data_df_copy = data_df.copy()
    data_df_copy['age_group'] = pd.cut(data_df_copy['age_years'], bins=bins, labels=labels)
    
    age_group_stats = []
    for grp in labels:
        subset = data_df_copy[data_df_copy['age_group'] == grp]
        cnt = len(subset)
        pos = int((subset['cardio'] == 1).sum()) if cnt > 0 else 0
        neg = cnt - pos
        rate = round((pos / cnt) * 100, 1) if cnt > 0 else 0
        age_group_stats.append({
            'group': grp,
            'total': cnt,
            'positive': pos,
            'negative': neg,
            'disease_rate': rate
        })

    # 2. Blood Pressure Categories
    # Use existing column or derive standard categories
    bp_cats = data_df_copy['blood_pressure_category'].value_counts()
    bp_stats = []
    for cat in ['Normal', 'Prehypertension', 'Hypertension Stage 1', 'Hypertension Stage 2']:
        subset = data_df_copy[data_df_copy['blood_pressure_category'] == cat]
        cnt = len(subset)
        if cnt == 0:
            continue
        pos = int((subset['cardio'] == 1).sum())
        neg = cnt - pos
        rate = round((pos / cnt) * 100, 1)
        bp_stats.append({
            'category': cat,
            'total': cnt,
            'positive': pos,
            'negative': neg,
            'disease_rate': rate
        })

    # 3. BMI Categories
    bmi_stats = []
    for cat in ['Wightloss', 'Normal', 'Overwight', 'Obesity class 1', 'Obesity class 2', 'Extreme Obesity']:
        subset = data_df_copy[data_df_copy['BMI_category'] == cat]
        cnt = len(subset)
        if cnt == 0:
            continue
        pos = int((subset['cardio'] == 1).sum())
        neg = cnt - pos
        rate = round((pos / cnt) * 100, 1)
        display_name = {
            'Wightloss': 'Underweight (<18.5)',
            'Normal': 'Normal (18.5-24.9)',
            'Overwight': 'Overweight (25-29.9)',
            'Obesity class 1': 'Obesity Class 1 (30-34.9)',
            'Obesity class 2': 'Obesity Class 2 (35-39.9)',
            'Extreme Obesity': 'Extreme Obesity (≥40)'
        }.get(cat, cat)
        bmi_stats.append({
            'category': cat,
            'display_name': display_name,
            'total': cnt,
            'positive': pos,
            'negative': neg,
            'disease_rate': rate
        })

    # 4. Cholesterol Levels
    chol_stats = []
    chol_labels = {1: 'Normal', 2: 'Above Normal', 3: 'Well Above Normal'}
    for level, label in chol_labels.items():
        subset = data_df_copy[data_df_copy['cholesterol'] == level]
        cnt = len(subset)
        pos = int((subset['cardio'] == 1).sum()) if cnt > 0 else 0
        neg = cnt - pos
        rate = round((pos / cnt) * 100, 1) if cnt > 0 else 0
        chol_stats.append({
            'level': level,
            'label': label,
            'total': cnt,
            'positive': pos,
            'negative': neg,
            'disease_rate': rate
        })

    # 5. Glucose Levels
    gluc_stats = []
    gluc_labels = {1: 'Normal', 2: 'Above Normal', 3: 'Well Above Normal'}
    for level, label in gluc_labels.items():
        subset = data_df_copy[data_df_copy['gluc'] == level]
        cnt = len(subset)
        pos = int((subset['cardio'] == 1).sum()) if cnt > 0 else 0
        neg = cnt - pos
        rate = round((pos / cnt) * 100, 1) if cnt > 0 else 0
        gluc_stats.append({
            'level': level,
            'label': label,
            'total': cnt,
            'positive': pos,
            'negative': neg,
            'disease_rate': rate
        })

    # 6. Lifestyle Factors
    lifestyle_stats = {
        'smoking': {
            'smokers_cvd_rate': round(float((data_df[data_df['smoke'] == 1]['cardio'] == 1).mean() * 100), 1),
            'nonsmokers_cvd_rate': round(float((data_df[data_df['smoke'] == 0]['cardio'] == 1).mean() * 100), 1),
            'total_smokers': smokers,
            'total_nonsmokers': total_patients - smokers
        },
        'alcohol': {
            'alcohol_cvd_rate': round(float((data_df[data_df['alco'] == 1]['cardio'] == 1).mean() * 100), 1),
            'nonalcohol_cvd_rate': round(float((data_df[data_df['alco'] == 0]['cardio'] == 1).mean() * 100), 1),
            'total_drinkers': alcohol,
            'total_nondrinkers': total_patients - alcohol
        },
        'active': {
            'active_cvd_rate': round(float((data_df[data_df['active'] == 1]['cardio'] == 1).mean() * 100), 1),
            'inactive_cvd_rate': round(float((data_df[data_df['active'] == 0]['cardio'] == 1).mean() * 100), 1),
            'total_active': active,
            'total_inactive': total_patients - active
        }
    }

    # 7. Gender Stats
    female_cnt = int((data_df['gender'] == 1).sum())
    male_cnt = int((data_df['gender'] == 2).sum())
    female_cvd_rate = round(float((data_df[data_df['gender'] == 1]['cardio'] == 1).mean() * 100), 1)
    male_cvd_rate = round(float((data_df[data_df['gender'] == 2]['cardio'] == 1).mean() * 100), 1)

    gender_stats = {
        'female_count': female_cnt,
        'male_count': male_cnt,
        'female_cvd_rate': female_cvd_rate,
        'male_cvd_rate': male_cvd_rate
    }

    # 8. Correlation Matrix
    corr_cols = ['age_years', 'ap_hi', 'ap_lo', 'Bmi', 'cholesterol', 'gluc', 'smoke', 'alco', 'active', 'cardio']
    corr_matrix = data_df[corr_cols].corr().round(3).to_dict()

    return {
        'kpis': {
            'total_patients': total_patients,
            'cardio_positive': cardio_pos,
            'cardio_negative': cardio_neg,
            'cardio_rate': cardio_rate,
            'avg_age': avg_age,
            'avg_bmi': avg_bmi,
            'avg_systolic': avg_sys,
            'avg_diastolic': avg_dia,
            'smokers_count': smokers,
            'alcohol_count': alcohol,
            'active_count': active,
            'smokers_percent': round((smokers / total_patients) * 100, 1),
            'active_percent': round((active / total_patients) * 100, 1),
        },
        'age_groups': age_group_stats,
        'blood_pressure': bp_stats,
        'bmi_distribution': bmi_stats,
        'cholesterol': chol_stats,
        'glucose': gluc_stats,
        'lifestyle': lifestyle_stats,
        'gender': gender_stats,
        'correlations': corr_matrix
    }

GLOBAL_STATS = compute_dataset_stats(df)

@app.route('/')
def index():
    """Renders the main dashboard."""
    return render_template('index.html')

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Returns dataset summary statistics and distributions."""
    return jsonify({
        'status': 'success',
        'data': GLOBAL_STATS
    })

@app.route('/api/models', methods=['GET'])
def get_models():
    """Returns ML performance benchmark and feature importances."""
    return jsonify({
        'status': 'success',
        'metrics': engine.metrics,
        'feature_importances': engine.feature_importances
    })

@app.route('/api/predict', methods=['POST'])
def predict_risk():
    """Predicts cardiovascular disease risk for a patient."""
    try:
        data = request.get_json(force=True)
        model_choice = data.get('model_choice', 'random_forest')
        
        patient_data = {
            'age_years': float(data.get('age_years', 50)),
            'gender': int(data.get('gender', 1)),
            'height': float(data.get('height', 165)),
            'weight': float(data.get('weight', 70)),
            'ap_hi': float(data.get('ap_hi', 120)),
            'ap_lo': float(data.get('ap_lo', 80)),
            'cholesterol': int(data.get('cholesterol', 1)),
            'gluc': int(data.get('gluc', 1)),
            'smoke': int(data.get('smoke', 0)),
            'alco': int(data.get('alco', 0)),
            'active': int(data.get('active', 1))
        }

        result = engine.predict_risk(patient_data, model_name=model_choice)
        return jsonify({
            'status': 'success',
            'data': result
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400

@app.route('/api/patients', methods=['GET'])
def get_patients():
    """Returns filtered, paginated patient records for the explorer table."""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 15))
        cardio = request.args.get('cardio', 'all')
        gender = request.args.get('gender', 'all')
        bp_cat = request.args.get('bp_category', 'all')
        bmi_cat = request.args.get('bmi_category', 'all')
        smoke = request.args.get('smoke', 'all')
        alco = request.args.get('alco', 'all')
        active = request.args.get('active', 'all')
        min_age = int(request.args.get('min_age', 30))
        max_age = int(request.args.get('max_age', 65))
        sort_by = request.args.get('sort_by', 'age_years')
        sort_order = request.args.get('sort_order', 'asc')

        filtered = df.copy()

        # Apply Filters
        filtered = filtered[(filtered['age_years'] >= min_age) & (filtered['age_years'] <= max_age)]

        if cardio != 'all':
            filtered = filtered[filtered['cardio'] == int(cardio)]
        if gender != 'all':
            filtered = filtered[filtered['gender'] == int(gender)]
        if bp_cat != 'all':
            filtered = filtered[filtered['blood_pressure_category'] == bp_cat]
        if bmi_cat != 'all':
            filtered = filtered[filtered['BMI_category'] == bmi_cat]
        if smoke != 'all':
            filtered = filtered[filtered['smoke'] == int(smoke)]
        if alco != 'all':
            filtered = filtered[filtered['alco'] == int(alco)]
        if active != 'all':
            filtered = filtered[filtered['active'] == int(active)]

        total_filtered = len(filtered)

        # Sorting
        if sort_by in filtered.columns:
            ascending = (sort_order == 'asc')
            filtered = filtered.sort_values(by=sort_by, ascending=ascending)

        # Pagination
        start_idx = (page - 1) * limit
        end_idx = start_idx + limit
        paginated_df = filtered.iloc[start_idx:end_idx]

        records = paginated_df.to_dict(orient='records')

        return jsonify({
            'status': 'success',
            'total': total_filtered,
            'page': page,
            'limit': limit,
            'total_pages': int(np.ceil(total_filtered / limit)) if limit > 0 else 1,
            'data': records
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@app.route('/api/export', methods=['GET'])
def export_patients():
    """Exports filtered dataset as CSV."""
    try:
        cardio = request.args.get('cardio', 'all')
        bp_cat = request.args.get('bp_category', 'all')
        bmi_cat = request.args.get('bmi_category', 'all')

        filtered = df.copy()
        if cardio != 'all':
            filtered = filtered[filtered['cardio'] == int(cardio)]
        if bp_cat != 'all':
            filtered = filtered[filtered['blood_pressure_category'] == bp_cat]
        if bmi_cat != 'all':
            filtered = filtered[filtered['BMI_category'] == bmi_cat]

        csv_buffer = io.StringIO()
        filtered.head(5000).to_csv(csv_buffer, index=False)
        csv_buffer.seek(0)

        return Response(
            csv_buffer.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": "attachment;filename=cardiovascular_patients_export.csv"}
        )
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"\n=======================================================")
    print(f" Cardio AI Analytics & Prediction Dashboard Running")
    print(f" URL: http://localhost:{port}")
    print(f"=======================================================\n")
    app.run(host='0.0.0.0', port=port, debug=False)
