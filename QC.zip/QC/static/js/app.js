/**
 * CardioPulse AI — Interactive Client Application
 * Chart.js Visualizations, Real-time ML Prediction, Bilingual (EN/GU), Data Explorer
 */

// Global State
let currentLang = 'en';
let currentTab = 'overview';
let globalStats = null;
let modelMetrics = null;
let charts = {};
let currentPage = 1;
let totalPages = 1;

// Bilingual Dictionary (English & Gujarati)
const I18N = {
    en: {
        tagline: "Cardiovascular Disease Analytics & AI Prediction",
        records_analyzed: "Patients Analyzed",
        tab_overview: "Executive Overview",
        tab_analytics: "Clinical Analytics (EDA)",
        tab_predictor: "AI Patient Risk Predictor",
        tab_models: "ML Model Benchmark",
        tab_explorer: "Patient Records Explorer",
        
        overview_title: "Executive Clinical Summary & Cohort KPIs",
        overview_desc: "High-level population health metrics from 68,822 validated patient records.",
        kpi_total_patients: "Total Patients",
        kpi_disease_prevalence: "CVD Prevalence Rate",
        kpi_avg_age: "Average Age",
        kpi_age_range: "Range: 30 to 65 Years",
        kpi_avg_bmi: "Average BMI",
        kpi_overweight_avg: "Overweight Cohort",
        kpi_avg_bp: "Mean Blood Pressure",
        kpi_bp_unit: "mmHg (Systolic / Diastolic)",
        kpi_active_rate: "Physically Active",
        kpi_smokers: "Tobacco Smokers",
        kpi_top_model: "Best AI Model",

        chart_cvd_dist_title: "Cardiovascular Disease Target Distribution",
        chart_cvd_dist_sub: "Proportion of patients diagnosed with CVD vs healthy controls",
        chart_age_risk_title: "Age Demographics vs Cardiovascular Disease Risk",
        chart_age_risk_sub: "Prevalence and patient volume across age brackets",

        insights_heading: "Key Clinical Findings from Dataset",
        insight1_title: "Blood Pressure is the #1 Predictor",
        insight1_desc: "Systolic & Diastolic BP account for over 62% of machine learning model feature importance.",
        insight2_title: "Age Risk Spike at 50+",
        insight2_desc: "CVD prevalence doubles from 25.1% in the 30-39 age bracket to 56.8% in patients aged 60-65.",
        insight3_title: "Severe Obesity Multiplier",
        insight3_desc: "Patients with BMI ≥ 35 have a 67.2% cardiovascular disease incidence rate compared to 39.8% with normal BMI.",
        insight4_title: "High Cholesterol Synergy",
        insight4_desc: "Level 3 cholesterol increases disease rate to 76.5%, acting as an exponential risk multiplier with hypertension.",

        analytics_title: "Exploratory Data Analysis & Clinical Risk Factors",
        analytics_desc: "Detailed multi-dimensional statistical correlations and risk factor breakdowns.",
        chart_bp_title: "Blood Pressure Category vs CVD Rate",
        chart_bp_sub: "Comparison from Normal to Hypertension Stage 2",
        chart_bmi_title: "Body Mass Index (BMI) Categories",
        chart_bmi_sub: "Disease incidence progression across weight classifications",
        chart_lab_title: "Biochemical Lab Tests (Cholesterol & Glucose)",
        chart_lab_sub: "Impact of Normal (1), Above Normal (2), and High (3) levels",
        chart_lifestyle_title: "Lifestyle & Behavioral Impact",
        chart_lifestyle_sub: "Smoking, Alcohol consumption, and Physical Activity correlations",
        heatmap_title: "Feature Correlation Matrix (Heatmap)",
        heatmap_sub: "Pearson correlation coefficient between clinical features and target disease diagnosis",

        predictor_title: "AI Cardiovascular Risk Assessment & Diagnostic Tool",
        predictor_desc: "Input patient clinical parameters to calculate instant risk probability, disease classification, and personalized advice.",
        preset_label: "Quick Demo Presets:",
        preset_high_risk: "55y Hypertensive Smoker (High Risk)",
        preset_healthy: "42y Active Healthy (Low Risk)",
        preset_senior: "63y High Cholesterol Senior (High Risk)",
        preset_overweight: "48y Overweight Prehypertension (Moderate)",

        patient_demographics: "1. Patient Demographics & Vitals",
        form_age: "Age (Years)",
        form_gender: "Gender",
        gender_female: "Female",
        gender_male: "Male",
        form_model: "ML Model",
        form_height: "Height (cm)",
        form_weight: "Weight (kg)",
        calc_bmi_label: "Calculated BMI:",
        blood_pressure_section: "2. Blood Pressure (mmHg)",
        form_ap_hi: "Systolic BP (ap_hi)",
        form_ap_lo: "Diastolic BP (ap_lo)",
        hint_systolic: "Normal: < 120 mmHg",
        hint_diastolic: "Normal: < 80 mmHg",
        calc_bp_label: "BP Stage:",
        lab_and_lifestyle: "3. Lab Markers & Lifestyle Habits",
        form_cholesterol: "Cholesterol Level",
        chol_1: "1: Normal (< 200 mg/dL)",
        chol_2: "2: Above Normal (200-239)",
        chol_3: "3: Well Above Normal (≥ 240)",
        form_glucose: "Glucose Level",
        gluc_1: "1: Normal (< 100 mg/dL)",
        gluc_2: "2: Above Normal (100-125)",
        gluc_3: "3: Well Above Normal (≥ 126)",
        toggle_smoke: "Tobacco Smoking",
        toggle_smoke_sub: "Active cigarette / bidi use",
        toggle_alco: "Alcohol Intake",
        toggle_alco_sub: "Regular alcohol consumption",
        toggle_active: "Physical Activity",
        toggle_active_sub: "Regular exercise or brisk walking",
        btn_predict: "Run AI Cardiovascular Risk Assessment",

        results_title: "Patient AI Diagnostic Report",
        prob_risk_label: "CVD Probability",
        contributing_factors_title: "Key Contributing Risk Drivers",
        clinical_guidance_title: "Actionable Clinical Advice",
        btn_print: "Print Diagnostic Report",
        btn_reset: "Reset Form",

        models_title: "Comparative Analysis of Machine Learning Algorithms",
        models_desc: "Performance evaluation of Logistic Regression, Decision Tree, and Random Forest on test split.",
        best_performing: "Best Model",
        rf_desc: "Ensemble of 100 decision trees with feature sub-sampling",
        lr_desc: "Linear probabilistic classification baseline",
        dt_desc: "Single optimized decision tree (depth=10)",
        metric_acc: "Accuracy",
        metric_auc: "ROC-AUC",
        metric_f1: "F1-Score",
        metric_precision: "Precision",
        chart_model_comp_title: "Multi-Metric Model Comparison",
        chart_model_comp_sub: "Side-by-side comparison across Accuracy, Precision, Recall, F1, and AUC",
        chart_feature_imp_title: "Feature Importance Ranking",
        chart_feature_imp_sub: "Gini importance computed via Random Forest Classifier",
        cm_title: "Confusion Matrix Analysis",
        cm_sub: "True Positive (TP), True Negative (TN), False Positive (FP), False Negative (FN) breakdown",

        explorer_title: "Patient Records Explorer & Clinical Query Engine",
        explorer_desc: "Search, filter, inspect and load real patient records into the AI Risk Predictor.",
        btn_export_csv: "Export CSV",
        filter_cvd_status: "CVD Status",
        filter_all: "All",
        filter_positive: "CVD Positive (Disease)",
        filter_negative: "CVD Negative (Healthy)",
        filter_bp_category: "BP Category",
        filter_bmi_category: "BMI Category",
        filter_gender: "Gender",
        filter_smoke: "Smoking",
        opt_smoker: "Smoker",
        opt_nonsmoker: "Non-Smoker",
        filter_sort: "Sort By",
        sort_age: "Age (Years)",
        sort_ap_hi: "Systolic BP",
        sort_bmi: "BMI",
        sort_chol: "Cholesterol",
        showing_records: "Showing",
        of: "of",
        matching_patients: "matching patient records",
        rows_per_page: "Rows per page:",
        th_patient_id: "#",
        th_age: "Age",
        th_gender: "Gender",
        th_height: "Height",
        th_weight: "Weight",
        th_bmi: "BMI",
        th_bp: "Blood Pressure",
        th_bp_stage: "BP Stage",
        th_chol: "Cholesterol",
        th_gluc: "Glucose",
        th_lifestyle: "Lifestyle",
        th_cvd_diag: "CVD Status",
        th_action: "Action",
        btn_prev: "Previous",
        btn_next: "Next",
        page: "Page"
    },
    gu: {
        tagline: "હૃદયરોગ વિશ્લેષણ અને AI રિસ્ક પ્રિડિક્શન પ્લેટફોર્મ",
        records_analyzed: "દર્દીઓનું વિશ્લેષણ",
        tab_overview: "મુખ્ય વિહંગાવલોકન",
        tab_analytics: "ક્લિનિકલ એનાલિટિક્સ (EDA)",
        tab_predictor: "AI પેશન્ટ રિસ્ક પ્રિડિક્ટર",
        tab_models: "ML મોડેલ સરખામણી",
        tab_explorer: "દર્દી ડેટા એક્સપ્લોરર",

        overview_title: "ક્લિનિકલ સારાંશ અને પોપ્યુલેશન KPIs",
        overview_desc: "૬૮,૮૨૨ પ્રમાણિત દર્દીઓના ડેટાના આધારે પૃથ્થકરણ.",
        kpi_total_patients: "કુલ દર્દીઓ",
        kpi_disease_prevalence: "હૃદયરોગ દર (CVD %)",
        kpi_avg_age: "સરેરાશ ઉંમર",
        kpi_age_range: "વિસ્તાર: ૩૦ થી ૬૫ વર્ષ",
        kpi_avg_bmi: "સરેરાશ BMI",
        kpi_overweight_avg: "વધારે વજન જૂથ",
        kpi_avg_bp: "સરેરાશ બ્લડ પ્રેશર",
        kpi_bp_unit: "mmHg (સિસ્ટોલિક / ડાયાસ્ટોલિક)",
        kpi_active_rate: "શારીરિક સક્રિય (કસરત)",
        kpi_smokers: "ધૂમ્રપાન ટેવ",
        kpi_top_model: "શ્રેષ્ઠ AI મોડેલ",

        chart_cvd_dist_title: "હૃદયરોગ નિદાન વિતરણ (Positive vs Healthy)",
        chart_cvd_dist_sub: "હૃદયરોગ ધરાવતા અને સ્વસ્થ દર્દીઓનું પ્રમાણ",
        chart_age_risk_title: "ઉંમર પ્રમાણે હૃદયરોગનું જોખમ",
        chart_age_risk_sub: "વિવિધ વય જૂથોમાં દર્દીઓની સંખ્યા અને જોખમ દર",

        insights_heading: "ડેટાસેટમાંથી મુખ્ય તારણો (Clinical Findings)",
        insight1_title: "બ્લડ પ્રેશર એ સૌથી મુખ્ય પરિબળ છે",
        insight1_desc: "સિસ્ટોલિક અને ડાયાસ્ટોલિક BP મોડેલમાં ૬૨% થી વધુ મહત્વ ધરાવે છે.",
        insight2_title: "૫૦ વર્ષ પછી જોખમમાં ઝડપી વધારો",
        insight2_desc: "૩૦-૩૯ વર્ષમાં ૨૫.૧% જોખમ સામે ૬૦-૬૫ વર્ષમાં વધીને ૫૬.૮% થાય છે.",
        insight3_title: "ગંભીર સ્થૂળતાથી જોખમમાં ઉછાળો",
        insight3_desc: "BMI ≥ 35 ધરાવતા દર્દીઓમાં હૃદયરોગનો દર ૬૭.૨% છે જે સામાન્ય વજન સામે ઘણો વધારે છે.",
        insight4_title: "હાઈ કોલેસ્ટ્રોલની ગંભીર અસર",
        insight4_desc: "સ્તર ૩ કોલેસ્ટ્રોલ ધરાવતા દર્દીઓમાં રોગનો દર ૭૬.૫% સુધી પહોંચે છે.",

        analytics_title: "ડેટા એનાલિટિક્સ અને જોખમી પરિબળો (EDA)",
        analytics_desc: "ક્લિનિકલ પરિબળો વચ્ચેનો આંતરસંબંધ અને વિગતવાર આંકડા.",
        chart_bp_title: "બ્લડ પ્રેશર સ્ટેજ અને રોગનો દર",
        chart_bp_sub: "સામાન્ય BP થી હાઈપરટેન્શન સ્ટેજ ૨ વચ્ચે સરખામણી",
        chart_bmi_title: "BMI વર્ગીકરણ પ્રમાણે રોગનું પ્રમાણ",
        chart_bmi_sub: "ઓછા વજનથી ગંભીર સ્થૂળતા સુધીનું વિશ્લેષણ",
        chart_lab_title: "લેબ પરીક્ષણ (કોલેસ્ટ્રોલ અને ગ્લુકોઝ)",
        chart_lab_sub: "સામાન્ય (૧), સામાન્યથી વધારે (૨) અને અતિ વધારે (૩) સ્તર",
        chart_lifestyle_title: "જીવનશૈલી પરિબળોની અસર",
        chart_lifestyle_sub: "ધૂમ્રપાન, આલ્કોહોલ અને કસરતની હૃદયરોગ પર અસર",
        heatmap_title: "પરિબળો વચ્ચેનો સહસંબંધ (Heatmap)",
        heatmap_sub: "ક્લિનિકલ ફીચર્સ અને હૃદયરોગ વચ્ચે પિયરસન કોરિલેશન",

        predictor_title: "AI કાર્ડિયોવાસ્ક્યુલર રિસ્ક પ્રિડિક્ટર",
        predictor_desc: "દર્દીના ક્લિનિકલ માપદંડો દાખલ કરીને રિયલ-ટાઇમ જોખમ સ્કોર અને સલાહ મેળવો.",
        preset_label: "ઝડપી ડેમો દર્દી પ્રોફાઇલ:",
        preset_high_risk: "૫૫વ હાઈ બ્લડપ્રેશર સ્મોકર (ઉચ્ચ જોખમ)",
        preset_healthy: "૪૨વ સક્રિય સ્વસ્થ દર્દી (ઓછું જોખમ)",
        preset_senior: "૬૩વ હાઈ કોલેસ્ટ્રોલ સિનિયર (ઉચ્ચ જોખમ)",
        preset_overweight: "૪૮વ વધારે વજન પ્રીહાઈપરટેન્શન (મધ્યમ)",

        patient_demographics: "૧. દર્દીની વિગતો અને વાઇટલ્સ",
        form_age: "ઉંમર (વર્ષ)",
        form_gender: "જાતિ",
        gender_female: "સ્ત્રી",
        gender_male: "પુરુષ",
        form_model: "ML મોડેલ પસંદ કરો",
        form_height: "ઊંચાઈ (સેમી)",
        form_weight: "વજન (કિલો)",
        calc_bmi_label: "ગણતરી કરેલ BMI:",
        blood_pressure_section: "૨. બ્લડ પ્રેશર (mmHg)",
        form_ap_hi: "સિસ્ટોલિક BP (ap_hi)",
        form_ap_lo: "ડાયાસ્ટોલિક BP (ap_lo)",
        hint_systolic: "સામાન્ય: < ૧૨૦ mmHg",
        hint_diastolic: "સામાન્ય: < ૮૦ mmHg",
        calc_bp_label: "BP કેટેગરી:",
        lab_and_lifestyle: "૩. લેબ રિપોર્ટ અને જીવનશૈલી ટેવો",
        form_cholesterol: "કોલેસ્ટ્રોલ સ્તર",
        chol_1: "૧: સામાન્ય (< ૨૦૦ mg/dL)",
        chol_2: "૨: વધારે (૨૦૦-૨૩૯)",
        chol_3: "૩: અતિ વધારે (≥ ૨૪૦)",
        form_glucose: "ગ્લુકોઝ સ્તર (શુગર)",
        gluc_1: "૧: સામાન્ય (< ૧૦૦ mg/dL)",
        gluc_2: "૨: પ્રી-ડાયાબિટીક (૧૦૦-૧૨૫)",
        gluc_3: "૩: ડાયાબિટીક (≥ ૧૨૬)",
        toggle_smoke: "ધૂમ્રપાન ટેવ",
        toggle_smoke_sub: "સિગારેટ કે બીડીનું સેવન",
        toggle_alco: "દારૂ / આલ્કોહોલ સેવન",
        toggle_alco_sub: "નિયમિત દારૂ પીવાની ટેવ",
        toggle_active: "શારીરિક કસરત",
        toggle_active_sub: "નિયમિત વ્યાયામ અથવા ઝડપી ચાલવું",
        btn_predict: "AI કાર્ડિયાક રિસ્ક ગણતરી કરો",

        results_title: "દર્દીનો AI ડાયગ્નોસ્ટિક રિપોર્ટ",
        prob_risk_label: "CVD સંભાવના (રિસ્ક)",
        contributing_factors_title: "મુખ્ય જોખમી પરિબળો",
        clinical_guidance_title: "ક્લિનિકલ અને જીવનશૈલી સલાહ",
        btn_print: "રિપોર્ટ પ્રિન્ટ કરો",
        btn_reset: "ફોર્મ રીસેટ કરો",

        models_title: "મશીન લર્નિંગ મોડેલ્સનું તુલનાત્મક વિશ્લેષણ",
        models_desc: "Logistic Regression, Decision Tree અને Random Forest મોડેલ્સનું ટેસ્ટ સ્પ્લિટ પર મૂલ્યાંકન.",
        best_performing: "શ્રેષ્ઠ મોડેલ",
        rf_desc: "૧૦૦ ડીસીઝન ટ્રીઝનું રેન્ડમ ફોરેસ્ટ એન્સેમ્બલ મોડેલ",
        lr_desc: "લીનિયર પ્રોબેલિસ્ટિક બેઝલાઇન ક્લાસિફિકેશન",
        dt_desc: "ઓપ્ટિમાઇઝ્ડ ડીસીઝન ટ્રી મોડેલ (Depth=10)",
        metric_acc: "એક્યુરેસી (Accuracy)",
        metric_auc: "ROC-AUC સ્કોર",
        metric_f1: "F1-Score",
        metric_precision: "પ્રેસિઝન (Precision)",
        chart_model_comp_title: "મોડેલ્સની બહુ-પરિમાણીય સરખામણી",
        chart_model_comp_sub: "Accuracy, Precision, Recall, F1 અને AUC ની સરખામણી",
        chart_feature_imp_title: "પરિબળોનું મહત્વ રેન્કિંગ (Feature Importance)",
        chart_feature_imp_sub: "રેન્ડમ ફોરેસ્ટ ગીની ઇમ્પોર્ટન્સ સ્કોર",
        cm_title: "કન્ફ્યુઝન મેટ્રિક્સ એનાલિસિસ",
        cm_sub: "True Positive, True Negative, False Positive, False Negative વિભાજન",

        explorer_title: "દર્દી ડેટા એક્સપ્લોરર",
        explorer_desc: "દર્દીઓનો ડેટા શોધો, ફિલ્ટર કરો અને AI પ્રિડિક્ટરમાં લોડ કરો.",
        btn_export_csv: "CSV ડાઉનલોડ",
        filter_cvd_status: "હૃદયરોગ સ્થિતિ",
        filter_all: "બધા",
        filter_positive: "CVD હાજર (Positive)",
        filter_negative: "CVD ગેરહાજર / સ્વસ્થ (Negative)",
        filter_bp_category: "BP કેટેગરી",
        filter_bmi_category: "BMI કેટેગરી",
        filter_gender: "જાતિ",
        filter_smoke: "ધૂમ્રપાન",
        opt_smoker: "સ્મોકર",
        opt_nonsmoker: "નોન-સ્મોકર",
        filter_sort: "સૉર્ટ કરો",
        sort_age: "ઉંમર (વર્ષ)",
        sort_ap_hi: "સિસ્ટોલિક BP",
        sort_bmi: "BMI",
        sort_chol: "કોલેસ્ટ્રોલ",
        showing_records: "દર્શાવેલ",
        of: "માંથી",
        matching_patients: "દર્દીઓના રેકોર્ડ્સ",
        rows_per_page: "પૃષ્ઠ દીઠ રેકોર્ડ્સ:",
        th_patient_id: "#",
        th_age: "ઉંમર",
        th_gender: "જાતિ",
        th_height: "ઊંચાઈ",
        th_weight: "વજન",
        th_bmi: "BMI",
        th_bp: "બ્લડ પ્રેશર",
        th_bp_stage: "BP સ્ટેજ",
        th_chol: "કોલેસ્ટ્રોલ",
        th_gluc: "ગ્લુકોઝ",
        th_lifestyle: "જીવનશૈલી",
        th_cvd_diag: "CVD સ્થિતિ",
        th_action: "ક્રિયા",
        btn_prev: "પાછળ",
        btn_next: "આગળ",
        page: "પૃષ્ઠ"
    }
};

// Initialize Application
document.addEventListener('DOMContentLoaded', async () => {
    // Lucide Icons
    if (window.lucide) {
        lucide.createIcons();
    }

    // Load initial calculations
    updateLiveCalculations();

    // Fetch Stats & Models from Backend
    await loadInitialData();

    // Initial prediction run for demo
    calculateRisk();

    // Load Patient Records
    fetchPatients(1);
});

// Switch Tab
function switchTab(tabId) {
    currentTab = tabId;
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));

    const activeBtn = Array.from(document.querySelectorAll('.tab-btn')).find(b => b.getAttribute('onclick')?.includes(tabId));
    if (activeBtn) activeBtn.classList.add('active');

    const targetPane = document.getElementById(`tab-${tabId}`);
    if (targetPane) targetPane.classList.add('active');

    // Trigger chart resize after tab display
    setTimeout(() => {
        Object.values(charts).forEach(c => c && c.resize && c.resize());
    }, 100);

    if (window.lucide) lucide.createIcons();
}

// Toggle Dark/Light Theme
function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme') || 'dark';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', newTheme);

    const iconLight = document.getElementById('theme-icon-light');
    const iconDark = document.getElementById('theme-icon-dark');
    if (newTheme === 'light') {
        iconLight.classList.remove('hidden');
        iconDark.classList.add('hidden');
    } else {
        iconLight.classList.add('hidden');
        iconDark.classList.remove('hidden');
    }

    // Re-render charts with updated theme colors
    if (globalStats && modelMetrics) {
        renderAllCharts();
    }
}

// Set Language
function setLanguage(lang) {
    currentLang = lang;
    document.getElementById('lang-en').classList.toggle('active', lang === 'en');
    document.getElementById('lang-gu').classList.toggle('active', lang === 'gu');

    const dict = I18N[lang] || I18N.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
            el.textContent = dict[key];
        }
    });

    updateLiveCalculations();
    if (window.lucide) lucide.createIcons();
}

// Fetch Initial Data
async function loadInitialData() {
    try {
        const [statsRes, modelsRes] = await Promise.all([
            fetch('/api/stats').then(r => r.json()),
            fetch('/api/models').then(r => r.json())
        ]);

        if (statsRes.status === 'success') {
            globalStats = statsRes.data;
            populateKPIs(globalStats.kpis);
        }

        if (modelsRes.status === 'success') {
            modelMetrics = modelsRes;
            populateModelMetrics(modelsRes.metrics);
        }

        renderAllCharts();
        renderCorrelationHeatmap(globalStats.correlations);
    } catch (err) {
        console.error("Error loading initial data:", err);
    }
}

// Populate KPI cards
function populateKPIs(kpis) {
    document.getElementById('kpi-total').textContent = kpis.total_patients.toLocaleString();
    document.getElementById('kpi-cvd-rate').textContent = `${kpis.cardio_rate}%`;
    document.getElementById('kpi-cvd-pos-count').textContent = `${kpis.cardio_positive.toLocaleString()} Diagnosed Cases`;
    document.getElementById('kpi-avg-age').innerHTML = `${kpis.avg_age} <small>yrs</small>`;
    document.getElementById('kpi-avg-bmi').innerHTML = `${kpis.avg_bmi} <small>kg/m²</small>`;
    document.getElementById('kpi-avg-bp').textContent = `${kpis.avg_systolic} / ${kpis.avg_diastolic}`;
    document.getElementById('kpi-active-rate').textContent = `${kpis.active_percent}%`;
    document.getElementById('kpi-active-count').textContent = `${kpis.active_count.toLocaleString()} Active Individuals`;
    document.getElementById('kpi-smokers').textContent = `${kpis.smokers_percent}%`;
    document.getElementById('kpi-smokers-count').textContent = `${kpis.smokers_count.toLocaleString()} Smokers`;
}

// Populate ML Models Tab
function populateModelMetrics(metrics) {
    if (!metrics) return;
    const rf = metrics.random_forest || {};
    const lr = metrics.logistic_regression || {};
    const dt = metrics.decision_tree || {};

    // RF
    document.getElementById('rf-acc').textContent = `${rf.accuracy}%`;
    document.getElementById('rf-auc').textContent = `${rf.roc_auc}%`;
    document.getElementById('rf-f1').textContent = `${rf.f1_score}%`;
    document.getElementById('rf-prec').textContent = `${rf.precision}%`;

    // LR
    document.getElementById('lr-acc').textContent = `${lr.accuracy}%`;
    document.getElementById('lr-auc').textContent = `${lr.roc_auc}%`;
    document.getElementById('lr-f1').textContent = `${lr.f1_score}%`;
    document.getElementById('lr-prec').textContent = `${lr.precision}%`;

    // DT
    document.getElementById('dt-acc').textContent = `${dt.accuracy}%`;
    document.getElementById('dt-auc').textContent = `${dt.roc_auc}%`;
    document.getElementById('dt-f1').textContent = `${dt.f1_score}%`;
    document.getElementById('dt-prec').textContent = `${dt.precision}%`;

    // Confusion Matrices
    if (rf.confusion_matrix) {
        document.getElementById('cm-rf-tn').textContent = rf.confusion_matrix.tn.toLocaleString();
        document.getElementById('cm-rf-fp').textContent = rf.confusion_matrix.fp.toLocaleString();
        document.getElementById('cm-rf-fn').textContent = rf.confusion_matrix.fn.toLocaleString();
        document.getElementById('cm-rf-tp').textContent = rf.confusion_matrix.tp.toLocaleString();
    }
    if (lr.confusion_matrix) {
        document.getElementById('cm-lr-tn').textContent = lr.confusion_matrix.tn.toLocaleString();
        document.getElementById('cm-lr-fp').textContent = lr.confusion_matrix.fp.toLocaleString();
        document.getElementById('cm-lr-fn').textContent = lr.confusion_matrix.fn.toLocaleString();
        document.getElementById('cm-lr-tp').textContent = lr.confusion_matrix.tp.toLocaleString();
    }
    if (dt.confusion_matrix) {
        document.getElementById('cm-dt-tn').textContent = dt.confusion_matrix.tn.toLocaleString();
        document.getElementById('cm-dt-fp').textContent = dt.confusion_matrix.fp.toLocaleString();
        document.getElementById('cm-dt-fn').textContent = dt.confusion_matrix.fn.toLocaleString();
        document.getElementById('cm-dt-tp').textContent = dt.confusion_matrix.tp.toLocaleString();
    }
}

// Render All Chart.js Charts
function renderAllCharts() {
    if (!globalStats) return;

    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    const textColor = isDark ? '#94a3b8' : '#475569';
    const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';

    Chart.defaults.color = textColor;
    Chart.defaults.font.family = "'Inter', sans-serif";

    // 1. CVD Donut Chart
    const ctxDonut = document.getElementById('chart-cvd-donut');
    if (ctxDonut) {
        if (charts.donut) charts.donut.destroy();
        charts.donut = new Chart(ctxDonut, {
            type: 'doughnut',
            data: {
                labels: ['CVD Positive (હૃદયરોગ હાજર)', 'Healthy Controls (સ્વસ્થ)'],
                datasets: [{
                    data: [globalStats.kpis.cardio_positive, globalStats.kpis.cardio_negative],
                    backgroundColor: ['#f43f5e', '#10b981'],
                    borderColor: isDark ? '#111827' : '#ffffff',
                    borderWidth: 3,
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 14, padding: 16 } },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => ` ${ctx.label}: ${ctx.raw.toLocaleString()} (${((ctx.raw / globalStats.kpis.total_patients) * 100).toFixed(1)}%)`
                        }
                    }
                },
                cutout: '70%'
            }
        });
    }

    // 2. Age Groups Chart
    const ctxAge = document.getElementById('chart-age-groups');
    if (ctxAge) {
        if (charts.age) charts.age.destroy();
        const ageLabels = globalStats.age_groups.map(a => `${a.group} Yrs`);
        const cvdRates = globalStats.age_groups.map(a => a.disease_rate);
        const totals = globalStats.age_groups.map(a => a.total);

        charts.age = new Chart(ctxAge, {
            type: 'bar',
            data: {
                labels: ageLabels,
                datasets: [
                    {
                        label: 'CVD Prevalence Rate (%)',
                        data: cvdRates,
                        backgroundColor: '#6366f1',
                        borderRadius: 6,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Total Patients in Cohort',
                        data: totals,
                        type: 'line',
                        borderColor: '#f59e0b',
                        backgroundColor: '#f59e0b',
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: {
                        position: 'left',
                        title: { display: true, text: 'Prevalence Rate (%)' },
                        grid: { color: gridColor },
                        max: 75
                    },
                    y1: {
                        position: 'right',
                        title: { display: true, text: 'Patient Count' },
                        grid: { display: false }
                    }
                }
            }
        });
    }

    // 3. BP Categories Chart
    const ctxBP = document.getElementById('chart-bp-categories');
    if (ctxBP) {
        if (charts.bp) charts.bp.destroy();
        const bpLabels = globalStats.blood_pressure.map(b => b.category);
        const bpRates = globalStats.blood_pressure.map(b => b.disease_rate);
        const bpColors = ['#10b981', '#3b82f6', '#f59e0b', '#f43f5e'];

        charts.bp = new Chart(ctxBP, {
            type: 'bar',
            data: {
                labels: bpLabels,
                datasets: [{
                    label: 'Disease Incidence Rate (%)',
                    data: bpRates,
                    backgroundColor: bpColors,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: { max: 100, grid: { color: gridColor }, title: { display: true, text: 'CVD Rate (%)' } }
                }
            }
        });
    }

    // 4. BMI Categories Chart
    const ctxBMI = document.getElementById('chart-bmi-categories');
    if (ctxBMI) {
        if (charts.bmi) charts.bmi.destroy();
        const bmiLabels = globalStats.bmi_distribution.map(b => b.display_name);
        const bmiRates = globalStats.bmi_distribution.map(b => b.disease_rate);

        charts.bmi = new Chart(ctxBMI, {
            type: 'bar',
            data: {
                labels: bmiLabels,
                datasets: [{
                    label: 'CVD Rate (%)',
                    data: bmiRates,
                    backgroundColor: ['#06b6d4', '#10b981', '#f59e0b', '#f97316', '#ef4444', '#b91c1c'],
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { max: 80, grid: { color: gridColor } },
                    y: { grid: { display: false } }
                }
            }
        });
    }

    // 5. Biochemical Lab Tests Chart
    const ctxLab = document.getElementById('chart-lab-markers');
    if (ctxLab) {
        if (charts.lab) charts.lab.destroy();
        charts.lab = new Chart(ctxLab, {
            type: 'bar',
            data: {
                labels: ['Level 1 (Normal)', 'Level 2 (Above Normal)', 'Level 3 (Well Above)'],
                datasets: [
                    {
                        label: 'Cholesterol CVD Rate (%)',
                        data: globalStats.cholesterol.map(c => c.disease_rate),
                        backgroundColor: '#8b5cf6',
                        borderRadius: 6
                    },
                    {
                        label: 'Glucose CVD Rate (%)',
                        data: globalStats.glucose.map(g => g.disease_rate),
                        backgroundColor: '#ec4899',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: { max: 90, grid: { color: gridColor } }
                }
            }
        });
    }

    // 6. Lifestyle Factors Chart
    const ctxLife = document.getElementById('chart-lifestyle');
    if (ctxLife) {
        if (charts.lifestyle) charts.lifestyle.destroy();
        const ls = globalStats.lifestyle;
        charts.lifestyle = new Chart(ctxLife, {
            type: 'bar',
            data: {
                labels: ['Tobacco Smoking', 'Alcohol Intake', 'Physical Inactivity'],
                datasets: [
                    {
                        label: 'Risk Factor Present (CVD %)',
                        data: [ls.smoking.smokers_cvd_rate, ls.alcohol.alcohol_cvd_rate, ls.active.inactive_cvd_rate],
                        backgroundColor: '#f43f5e',
                        borderRadius: 6
                    },
                    {
                        label: 'Risk Factor Absent / Healthy (CVD %)',
                        data: [ls.smoking.nonsmokers_cvd_rate, ls.alcohol.nonalcohol_cvd_rate, ls.active.active_cvd_rate],
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: { max: 65, grid: { color: gridColor } }
                }
            }
        });
    }

    // 7. ML Model Comparison Chart
    const ctxModel = document.getElementById('chart-model-comparison');
    if (ctxModel && modelMetrics && modelMetrics.metrics) {
        if (charts.models) charts.models.destroy();
        const m = modelMetrics.metrics;
        charts.models = new Chart(ctxModel, {
            type: 'bar',
            data: {
                labels: ['Accuracy (%)', 'Precision (%)', 'Recall (%)', 'F1-Score (%)', 'ROC-AUC (%)'],
                datasets: [
                    {
                        label: 'Random Forest (Ensemble)',
                        data: [m.random_forest.accuracy, m.random_forest.precision, m.random_forest.recall, m.random_forest.f1_score, m.random_forest.roc_auc],
                        backgroundColor: '#10b981',
                        borderRadius: 6
                    },
                    {
                        label: 'Logistic Regression',
                        data: [m.logistic_regression.accuracy, m.logistic_regression.precision, m.logistic_regression.recall, m.logistic_regression.f1_score, m.logistic_regression.roc_auc],
                        backgroundColor: '#6366f1',
                        borderRadius: 6
                    },
                    {
                        label: 'Decision Tree',
                        data: [m.decision_tree.accuracy, m.decision_tree.precision, m.decision_tree.recall, m.decision_tree.f1_score, m.decision_tree.roc_auc],
                        backgroundColor: '#f59e0b',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { display: false } },
                    y: { min: 50, max: 90, grid: { color: gridColor } }
                }
            }
        });
    }

    // 8. Feature Importance Chart
    const ctxFeat = document.getElementById('chart-feature-importance');
    if (ctxFeat && modelMetrics && modelMetrics.feature_importances) {
        if (charts.features) charts.features.destroy();
        const topFeats = modelMetrics.feature_importances.slice(0, 7);
        charts.features = new Chart(ctxFeat, {
            type: 'bar',
            data: {
                labels: topFeats.map(f => f.feature_name),
                datasets: [{
                    label: 'Feature Importance Score (%)',
                    data: topFeats.map(f => f.importance),
                    backgroundColor: '#06b6d4',
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { grid: { color: gridColor }, title: { display: true, text: 'Importance (%)' } },
                    y: { grid: { display: false } }
                }
            }
        });
    }
}

// Render Correlation Heatmap
function renderCorrelationHeatmap(corr) {
    const container = document.getElementById('correlation-heatmap');
    if (!container || !corr) return;

    const cols = Object.keys(corr);
    const friendlyNames = {
        'age_years': 'Age',
        'ap_hi': 'Systolic BP',
        'ap_lo': 'Diastolic BP',
        'Bmi': 'BMI',
        'cholesterol': 'Cholesterol',
        'gluc': 'Glucose',
        'smoke': 'Smoking',
        'alco': 'Alcohol',
        'active': 'Activity',
        'cardio': 'CVD Target'
    };

    let html = '<table class="heatmap-table"><thead><tr><th>Feature</th>';
    cols.forEach(c => {
        html += `<th>${friendlyNames[c] || c}</th>`;
    });
    html += '</tr></thead><tbody>';

    cols.forEach(r => {
        html += `<tr><th>${friendlyNames[r] || r}</th>`;
        cols.forEach(c => {
            const val = corr[r][c];
            // Compute color intensity
            let bg = '';
            let text = '#f8fafc';
            if (val === 1) {
                bg = 'rgba(99, 102, 241, 0.8)';
            } else if (val > 0) {
                const alpha = Math.min(Math.abs(val) * 1.5, 0.85);
                bg = `rgba(244, 63, 94, ${alpha})`;
            } else {
                const alpha = Math.min(Math.abs(val) * 1.5, 0.85);
                bg = `rgba(16, 185, 129, ${alpha})`;
            }
            html += `<td class="heatmap-cell" style="background:${bg}; color:${text};" title="${friendlyNames[r]} x ${friendlyNames[c]}: ${val}">${val}</td>`;
        });
        html += '</tr>';
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}

// Live Calculations on Predictor Form
function updateLiveCalculations() {
    const height = parseFloat(document.getElementById('inp-height')?.value) || 170;
    const weight = parseFloat(document.getElementById('inp-weight')?.value) || 70;
    const apHi = parseFloat(document.getElementById('inp-ap-hi')?.value) || 120;
    const apLo = parseFloat(document.getElementById('inp-ap-lo')?.value) || 80;

    // BMI
    const heightM = height / 100;
    const bmi = (weight / (heightM * heightM)).toFixed(1);
    const bmiValEl = document.getElementById('live-bmi-val');
    const bmiBadgeEl = document.getElementById('live-bmi-badge');

    if (bmiValEl && bmiBadgeEl) {
        bmiValEl.textContent = `${bmi} kg/m²`;
        if (bmi < 18.5) {
            bmiBadgeEl.className = 'pill pill-blue';
            bmiBadgeEl.textContent = currentLang === 'gu' ? 'ઓછું વજન (Underweight)' : 'Underweight (<18.5)';
        } else if (bmi < 25) {
            bmiBadgeEl.className = 'pill pill-green';
            bmiBadgeEl.textContent = currentLang === 'gu' ? 'સામાન્ય વજન (Normal)' : 'Normal (18.5-24.9)';
        } else if (bmi < 30) {
            bmiBadgeEl.className = 'pill pill-amber';
            bmiBadgeEl.textContent = currentLang === 'gu' ? 'વધારે વજન (Overweight)' : 'Overweight (25-29.9)';
        } else {
            bmiBadgeEl.className = 'pill pill-rose';
            bmiBadgeEl.textContent = currentLang === 'gu' ? 'સ્થૂળતા (Obese)' : 'Obesity (≥30)';
        }
    }

    // BP Stage
    const bpValEl = document.getElementById('live-bp-val');
    const bpBadgeEl = document.getElementById('live-bp-badge');
    if (bpValEl && bpBadgeEl) {
        bpValEl.textContent = `${apHi} / ${apLo} mmHg`;
        if (apHi < 120 && apLo < 80) {
            bpBadgeEl.className = 'pill pill-green';
            bpBadgeEl.textContent = currentLang === 'gu' ? 'સામાન્ય (Normal BP)' : 'Normal BP';
        } else if (apHi <= 129 && apLo < 80) {
            bpBadgeEl.className = 'pill pill-blue';
            bpBadgeEl.textContent = currentLang === 'gu' ? 'વધેલું BP (Elevated)' : 'Elevated BP';
        } else if (apHi <= 139 || apLo <= 89) {
            bpBadgeEl.className = 'pill pill-amber';
            bpBadgeEl.textContent = currentLang === 'gu' ? 'હાઈપરટેન્શન સ્ટેજ ૧' : 'Hypertension Stage 1';
        } else {
            bpBadgeEl.className = 'pill pill-rose';
            bpBadgeEl.textContent = currentLang === 'gu' ? 'હાઈપરટેન્શન સ્ટેજ ૨' : 'Hypertension Stage 2';
        }
    }
}

// Quick Presets Loader
function loadPreset(type) {
    if (type === 'high_risk') {
        document.getElementById('inp-age').value = 55;
        document.getElementById('inp-gender').value = 2; // Male
        document.getElementById('inp-height').value = 170;
        document.getElementById('inp-weight').value = 88;
        document.getElementById('inp-ap-hi').value = 150;
        document.getElementById('inp-ap-lo').value = 95;
        document.getElementById('inp-cholesterol').value = 3;
        document.getElementById('inp-glucose').value = 2;
        document.getElementById('inp-smoke').checked = true;
        document.getElementById('inp-alco').checked = false;
        document.getElementById('inp-active').checked = false;
    } else if (type === 'healthy') {
        document.getElementById('inp-age').value = 42;
        document.getElementById('inp-gender').value = 1; // Female
        document.getElementById('inp-height').value = 164;
        document.getElementById('inp-weight').value = 58;
        document.getElementById('inp-ap-hi').value = 115;
        document.getElementById('inp-ap-lo').value = 75;
        document.getElementById('inp-cholesterol').value = 1;
        document.getElementById('inp-glucose').value = 1;
        document.getElementById('inp-smoke').checked = false;
        document.getElementById('inp-alco').checked = false;
        document.getElementById('inp-active').checked = true;
    } else if (type === 'senior_risk') {
        document.getElementById('inp-age').value = 63;
        document.getElementById('inp-gender').value = 1;
        document.getElementById('inp-height').value = 156;
        document.getElementById('inp-weight').value = 78;
        document.getElementById('inp-ap-hi').value = 145;
        document.getElementById('inp-ap-lo').value = 90;
        document.getElementById('inp-cholesterol').value = 3;
        document.getElementById('inp-glucose').value = 3;
        document.getElementById('inp-smoke').checked = false;
        document.getElementById('inp-alco').checked = false;
        document.getElementById('inp-active').checked = true;
    } else if (type === 'overweight') {
        document.getElementById('inp-age').value = 48;
        document.getElementById('inp-gender').value = 2;
        document.getElementById('inp-height').value = 175;
        document.getElementById('inp-weight').value = 85;
        document.getElementById('inp-ap-hi').value = 130;
        document.getElementById('inp-ap-lo').value = 85;
        document.getElementById('inp-cholesterol').value = 2;
        document.getElementById('inp-glucose').value = 1;
        document.getElementById('inp-smoke').checked = false;
        document.getElementById('inp-alco').checked = false;
        document.getElementById('inp-active').checked = true;
    }

    updateLiveCalculations();
    calculateRisk();
}

// Calculate Risk (AJAX POST)
async function calculateRisk() {
    const btn = document.getElementById('btn-predict');
    if (btn) {
        btn.innerHTML = `<i data-lucide="loader-2" class="spin-icon"></i> ${currentLang === 'gu' ? 'ગણતરી ચાલુ છે...' : 'Analyzing Patient Data...'}`;
        if (window.lucide) lucide.createIcons();
    }

    const payload = {
        age_years: parseFloat(document.getElementById('inp-age').value),
        gender: parseInt(document.getElementById('inp-gender').value),
        height: parseFloat(document.getElementById('inp-height').value),
        weight: parseFloat(document.getElementById('inp-weight').value),
        ap_hi: parseFloat(document.getElementById('inp-ap-hi').value),
        ap_lo: parseFloat(document.getElementById('inp-ap-lo').value),
        cholesterol: parseInt(document.getElementById('inp-cholesterol').value),
        gluc: parseInt(document.getElementById('inp-glucose').value),
        smoke: document.getElementById('inp-smoke').checked ? 1 : 0,
        alco: document.getElementById('inp-alco').checked ? 1 : 0,
        active: document.getElementById('inp-active').checked ? 1 : 0,
        model_choice: document.getElementById('inp-model').value
    };

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const res = await response.json();
        if (res.status === 'success') {
            displayPredictionResults(res.data);
        }
    } catch (err) {
        console.error("Prediction Error:", err);
    } finally {
        if (btn) {
            btn.innerHTML = `<i data-lucide="zap"></i> <span>${currentLang === 'gu' ? 'AI કાર્ડિયાક રિસ્ક ગણતરી કરો' : 'Run AI Cardiovascular Risk Assessment'}</span>`;
            if (window.lucide) lucide.createIcons();
        }
    }
}

// Display Prediction Results
function displayPredictionResults(data) {
    const prob = data.risk_probability;
    const isGu = currentLang === 'gu';

    // Update Percentage
    document.getElementById('res-risk-percent').textContent = `${prob}%`;
    document.getElementById('res-model-badge').textContent = `${data.model_used} (${data.model_accuracy}% Acc)`;

    // Update Progress Gauge
    const circleMeter = document.getElementById('risk-circle-meter');
    const degrees = (prob / 100) * 360;
    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    const bgEmpty = isDark ? '#1e293b' : '#e2e8f0';
    circleMeter.style.background = `conic-gradient(${data.risk_color} 0deg, ${data.risk_color} ${degrees}deg, ${bgEmpty} ${degrees}deg 360deg)`;

    // Update Tier Pill
    const tierPill = document.getElementById('res-risk-tier');
    const tierText = isGu ? data.risk_tier_gu : data.risk_tier;
    tierPill.textContent = tierText.toUpperCase();
    tierPill.style.background = `${data.risk_color}22`;
    tierPill.style.color = data.risk_color;
    tierPill.style.border = `1px solid ${data.risk_color}`;

    // Summary description
    const summaryEl = document.getElementById('res-risk-summary');
    if (prob >= 75) {
        summaryEl.textContent = isGu 
            ? "હૃદયરોગનું અતિ ગંભીર જોખમ. તાત્કાલિક કાર્ડિયોલોજિસ્ટ કન્સલ્ટેશન અને દવાઓની જરૂરિયાત."
            : "Critical probability of cardiovascular disease. Immediate clinical intervention and diagnostic tests advised.";
    } else if (prob >= 50) {
        summaryEl.textContent = isGu
            ? "હૃદયરોગનું ઉચ્ચ જોખમ. બ્લડ પ્રેશર અને કોલેસ્ટ્રોલ નિયંત્રણ માટે સક્રિય પગલાં જરૂરી છે."
            : "High risk profile detected. Close monitoring of lipid panel, hypertension management, and lifestyle modification advised.";
    } else if (prob >= 25) {
        summaryEl.textContent = isGu
            ? "મધ્યમ જોખમ. યોગ્ય ખોરાક અને નિયમિત કસરત દ્વારા જોખમ ઘટાડી શકાય છે."
            : "Moderate risk level. Preventive lifestyle adjustments, balanced nutrition, and regular checkups recommended.";
    } else {
        summaryEl.textContent = isGu
            ? "ઓછું જોખમ. દર્દીના કાર્ડિયોવાસ્ક્યુલર પેરામીટર્સ સામાન્ય શ્રેણીમાં છે."
            : "Low risk profile. Patient exhibits healthy cardiac vitals and low likelihood of CVD.";
    }

    // Drivers list
    const driversList = document.getElementById('res-drivers-list');
    driversList.innerHTML = '';
    data.drivers.forEach(d => {
        const tag = document.createElement('span');
        tag.className = `factor-tag ${d.type}`;
        tag.innerHTML = `<i data-lucide="${d.type === 'positive' ? 'check-circle' : 'alert-circle'}" style="width:13px;height:13px;"></i> ${isGu ? d.factor_gu : d.factor}`;
        driversList.appendChild(tag);
    });

    // Recommendations list
    const recList = document.getElementById('res-rec-list');
    recList.innerHTML = '';
    const recs = isGu ? data.recommendations_gu : data.recommendations;
    recs.forEach(r => {
        const li = document.createElement('li');
        li.textContent = r;
        recList.appendChild(li);
    });

    if (window.lucide) lucide.createIcons();
}

// Reset Predictor Form
function resetForm() {
    loadPreset('healthy');
}

// Fetch Paginated Patients Data
async function fetchPatients(page = 1) {
    currentPage = page;
    const tbody = document.getElementById('patients-table-body');
    if (!tbody) return;

    tbody.innerHTML = `<tr><td colspan="13" class="text-center py-6"><i data-lucide="loader-2" class="spin-icon"></i> ${currentLang === 'gu' ? 'દર્દીઓનો ડેટા લોડ થઈ રહ્યો છે...' : 'Loading patient records...'}</td></tr>`;
    if (window.lucide) lucide.createIcons();

    const limit = document.getElementById('tbl-limit')?.value || 15;
    const cardio = document.getElementById('filter-cardio')?.value || 'all';
    const bp = document.getElementById('filter-bp')?.value || 'all';
    const bmi = document.getElementById('filter-bmi')?.value || 'all';
    const gender = document.getElementById('filter-gender')?.value || 'all';
    const smoke = document.getElementById('filter-smoke')?.value || 'all';
    const sort = document.getElementById('filter-sort')?.value || 'age_years';

    const url = `/api/patients?page=${page}&limit=${limit}&cardio=${cardio}&bp_category=${bp}&bmi_category=${bmi}&gender=${gender}&smoke=${smoke}&sort_by=${sort}`;

    try {
        const res = await fetch(url).then(r => r.json());
        if (res.status === 'success') {
            totalPages = res.total_pages;
            renderPatientTable(res.data, res.total, page, parseInt(limit));
        }
    } catch (err) {
        console.error("Error fetching patients:", err);
        tbody.innerHTML = `<tr><td colspan="13" class="text-center py-6 text-rose">Error loading data.</td></tr>`;
    }
}

// Render Patient Records in Table
function renderPatientTable(records, total, page, limit) {
    const tbody = document.getElementById('patients-table-body');
    if (!tbody) return;

    const startIdx = (page - 1) * limit + 1;
    const endIdx = Math.min(page * limit, total);

    document.getElementById('tbl-start-idx').textContent = total > 0 ? startIdx.toLocaleString() : 0;
    document.getElementById('tbl-end-idx').textContent = endIdx.toLocaleString();
    document.getElementById('tbl-total-records').textContent = total.toLocaleString();
    document.getElementById('current-page-num').textContent = page;
    document.getElementById('total-page-num').textContent = totalPages || 1;

    document.getElementById('btn-prev-page').disabled = page <= 1;
    document.getElementById('btn-next-page').disabled = page >= totalPages;

    if (records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="13" class="text-center py-6 text-muted">${currentLang === 'gu' ? 'કોઈ દર્દીનો રેકોર્ડ મળ્યો નથી' : 'No matching patient records found.'}</td></tr>`;
        return;
    }

    let rowsHtml = '';
    records.forEach((r, idx) => {
        const globalRowIdx = startIdx + idx;
        const genderLabel = r.gender === 1 ? 'Female (F)' : 'Male (M)';
        const cvdBadge = r.cardio === 1 
            ? `<span class="pill pill-rose">CVD Positive</span>`
            : `<span class="pill pill-green">Normal</span>`;
        
        let bpBadgeClass = 'pill-green';
        if (r.blood_pressure_category?.includes('Stage 2')) bpBadgeClass = 'pill-rose';
        else if (r.blood_pressure_category?.includes('Stage 1')) bpBadgeClass = 'pill-amber';
        else if (r.blood_pressure_category?.includes('Prehypertension')) bpBadgeClass = 'pill-blue';

        const lifestyleTags = [];
        if (r.smoke === 1) lifestyleTags.push('🚬 Smoker');
        if (r.alco === 1) lifestyleTags.push('🍷 Alcohol');
        if (r.active === 1) lifestyleTags.push('🏃 Active');
        else lifestyleTags.push('🛋️ Sedentary');

        // Clean JSON payload for loading
        const rowJson = JSON.stringify({
            age_years: r.age_years,
            gender: r.gender,
            height: r.height,
            weight: r.weight,
            ap_hi: r.ap_hi,
            ap_lo: r.ap_lo,
            cholesterol: r.cholesterol,
            gluc: r.gluc,
            smoke: r.smoke,
            alco: r.alco,
            active: r.active
        }).replace(/"/g, '&quot;');

        rowsHtml += `
            <tr>
                <td><strong>#${globalRowIdx}</strong></td>
                <td>${r.age_years} yrs</td>
                <td>${genderLabel}</td>
                <td>${r.height} cm</td>
                <td>${r.weight} kg</td>
                <td><strong>${r.Bmi}</strong> <small class="text-muted">(${r.BMI_category})</small></td>
                <td><strong>${r.ap_hi} / ${r.ap_lo}</strong></td>
                <td><span class="pill ${bpBadgeClass}">${r.blood_pressure_category}</span></td>
                <td>Level ${r.cholesterol}</td>
                <td>Level ${r.gluc}</td>
                <td><small>${lifestyleTags.join(' • ')}</small></td>
                <td>${cvdBadge}</td>
                <td>
                    <button class="btn-action-small" onclick="loadPatientToPredictor(${rowJson})">
                        <i data-lucide="arrow-up-right" style="width:12px;height:12px;vertical-align:-1px;"></i> Load
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = rowsHtml;
    if (window.lucide) lucide.createIcons();
}

// Load patient from table directly to Predictor
function loadPatientToPredictor(p) {
    document.getElementById('inp-age').value = p.age_years;
    document.getElementById('inp-gender').value = p.gender;
    document.getElementById('inp-height').value = p.height;
    document.getElementById('inp-weight').value = p.weight;
    document.getElementById('inp-ap-hi').value = p.ap_hi;
    document.getElementById('inp-ap-lo').value = p.ap_lo;
    document.getElementById('inp-cholesterol').value = p.cholesterol;
    document.getElementById('inp-glucose').value = p.gluc;
    document.getElementById('inp-smoke').checked = p.smoke === 1;
    document.getElementById('inp-alco').checked = p.alco === 1;
    document.getElementById('inp-active').checked = p.active === 1;

    switchTab('predictor');
    updateLiveCalculations();
    calculateRisk();
}

// Change Page
function changePage(delta) {
    const targetPage = currentPage + delta;
    if (targetPage >= 1 && targetPage <= totalPages) {
        fetchPatients(targetPage);
    }
}

// Export CSV
function exportData() {
    const cardio = document.getElementById('filter-cardio')?.value || 'all';
    const bp = document.getElementById('filter-bp')?.value || 'all';
    const bmi = document.getElementById('filter-bmi')?.value || 'all';
    window.location.href = `/api/export?cardio=${cardio}&bp_category=${bp}&bmi_category=${bmi}`;
}
